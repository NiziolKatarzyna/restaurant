import styles from './TextInput.module.scss';
import { useState } from 'react';
const TextInput = (props) => {
  const [value, setValue] = useState(props.value);

  const handleChange = (e) => {
    const newValue = e.target.value;
    setValue(newValue);
    props.onChange(newValue);
  };
  return (
    <input
      className={styles.input}
      value={value}
      onChange={props.onChange}
      placeholder={props.placeholder}
      type='text'
    />
  );
};
export default TextInput;
