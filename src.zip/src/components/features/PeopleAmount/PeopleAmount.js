import styles from './PeopleAmount.module.scss';
import TextInput from '../../common/TextInput/TextInput';
import { useState } from 'react';

const PeopleAmount = () => {
  const [peopleAmount, setPeopleAmount] = useState(0);
  const [maxPeopleAmount, setMaxPeopleAmount] = useState(0);

  const handlePeopleAmountChange = (newValue) => {
    if (!isNaN(newValue) && newValue >= 0 && newValue <= 10) {
      setPeopleAmount(newValue);
    }
  };

  const handleMaxPeopleAmountChange = (newValue) => {
    if (!isNaN(newValue) && newValue >= 0 && newValue <= 10) {
      setMaxPeopleAmount(newValue);
    }
  };
  return (
    <li className={styles.list}>
      <h3 className={styles.title}>People: </h3>
      <TextInput
        type='number'
        value={peopleAmount}
        onChange={handlePeopleAmountChange}
      />
      <span className={styles.span}>/</span>
      <TextInput
        type='number'
        value={maxPeopleAmount}
        onChange={handleMaxPeopleAmountChange}
      />
    </li>
  );
};
export default PeopleAmount;
