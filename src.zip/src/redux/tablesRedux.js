//selectors
export const getAllTables = (state) => state.tables;
export const getTableById = ({ tables }, tableId) =>
  tables.find((table) => table.id === tableId);

// actions
const createActionName = (actionName) => `app/tables/${actionName}`;
const UPDATE_TABLES = createActionName('UPDATE_TABLES');

const UPDATE_TABLE_STATUS = createActionName('UPDATE_TABLE_STATUS');

// action creators
export const updateTables = (payload) => ({ type: UPDATE_TABLES, payload });

export const fetchTables = () => {
  return (dispatch) => {
    fetch('http://localhost:3131/tables')
      .then((res) => res.json())
      .then((tables) => dispatch(updateTables(tables)));
  };
};

export const updateTableStatus = (tableId, status) => (dispatch) => {
  fetch(`http://localhost:3131/tables/${tableId}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ status }),
  })
    .then((res) => res.json())
    .then((updatedTable) => {
      dispatch({
        type: UPDATE_TABLE_STATUS,
        payload: { tableId, status: updatedTable.status },
      });
    });
};

const tablesReducer = (statePart = [], action) => {
  switch (action.type) {
    case UPDATE_TABLES:
      return [...action.payload];
    case UPDATE_TABLE_STATUS:
      return statePart.map((table) =>
        table.id === action.payload.tableId
          ? { ...table, status: action.payload.status }
          : table
      );
    default:
      return statePart;
  }
};
export default tablesReducer;
