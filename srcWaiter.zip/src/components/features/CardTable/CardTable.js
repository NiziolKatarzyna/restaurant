import styles from './CardTable.module.scss';
import ButtonTable from '../../common/Button/Button';
import { NavLink } from 'react-router-dom';
import { Button } from 'react-bootstrap';

const CardTable = (props) => {
  let tableId; // Zmienna do przechowania identyfikatora jako liczby

  // Sprawdzenie typu identyfikatora i ewentualna konwersja na liczbę
  if (typeof props.tableId === 'number') {
    tableId = props.tableId;
  } else if (!isNaN(props.tableId)) {
    tableId = parseInt(props.tableId);
  } else {
    // Obsługa przypadku, gdy identyfikator jest innym typem
    console.error('Nieprawidłowy format identyfikatora stolika');
    return null; // Możesz zdecydować, jak obsłużyć błąd w przypadku nieprawidłowego formatu
  }
  return (
    <li className={styles.list}>
      <h2 className={styles.title}>Table: {props.tableId}</h2>
      <span className={styles.status}>Status: {props.status} </span>
      <Button as={NavLink} to={`/table/${props.tableId}`}>
        <span>Show More</span>
      </Button>
    </li>
  );
};
export default CardTable;
